let tips = [
    "Naszą oficjalną stroną jest flowrp.pl!",
    "Czy wiesz, że kanał propozycje jest dla nas skarbnicą wiedzy na kolejne aktualizacje?",
    "Naciśnij <span class='bold'>SPACJĘ</span> aby zatrzymać muzykę.",
    "Zapoznaj się z regulaminem serwera, aby uniknąć nieprzyjemnych sytuacji.",
    "Regularnie sprawdzaj discord, aby być na bieżąco z najnowszymi wydarzeniami!",
    "Potrzebujesz pomocy? Utwórz ticket bądź zgłoś się do administracji.",
    "Pamiętaj, aby zawsze grać zgodnie z zasadami roleplay!",
    "Dołącz do naszej społeczności na Discordzie, aby poznać innych graczy.",
    "Dbaj o immersję i realizm podczas gry – twórz autentyczne historie!"
];


const getRandomTip = () => {
    return tips[Math.floor(Math.random() * tips.length)]
}